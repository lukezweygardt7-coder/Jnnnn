package bbsmobspawner;

import mchorse.bbs_mod.data.DataToString;
import mchorse.bbs_mod.entity.IEntityFormProvider;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.entities.MCEntity;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.forms.ModelForm;
import mchorse.bbs_mod.network.ServerNetwork;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttribute;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.PathAwareEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/**
 * A normal pathfinding mob (walks, wanders, can be hostile, can be frozen in place)
 * that is drawn as a BBS morph/form. It is NOT a BBS film actor.
 */
public class CustomMobEntity extends PathAwareEntity implements IEntityFormProvider {
    private static final TrackedData<Float> BOX_W = DataTracker.registerData(CustomMobEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> BOX_H = DataTracker.registerData(CustomMobEntity.class, TrackedDataHandlerRegistry.FLOAT);

    private MobSettings settings; // can be null while the super constructor runs
    private Form form;
    private final MCEntity mcEntity = new MCEntity(this);

    public CustomMobEntity(EntityType<? extends CustomMobEntity> type, World world) {
        super(type, world);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return MobEntity.createMobAttributes().add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 2.0);
    }

    public static Form defaultForm() {
        ModelForm steve = new ModelForm();
        steve.model.set("player/steve");
        return steve;
    }

    @Override
    protected void initDataTracker() {
        super.initDataTracker();
        this.dataTracker.startTracking(BOX_W, 0.6F);
        this.dataTracker.startTracking(BOX_H, 1.8F);
    }

    @Override
    public void onTrackedDataSet(TrackedData<?> data) {
        super.onTrackedDataSet(data);
        if (BOX_W.equals(data) || BOX_H.equals(data)) {
            this.calculateDimensions();
        }
    }

    @Override
    public EntityDimensions getDimensions(EntityPose pose) {
        return EntityDimensions.changing(this.dataTracker.get(BOX_W), this.dataTracker.get(BOX_H));
    }

    // ---------------- settings ----------------

    public MobSettings getSettings() {
        return this.settings;
    }

    public void applySettings(MobSettings s, boolean resetHealth) {
        this.settings = s;

        this.setAttribute(EntityAttributes.GENERIC_MAX_HEALTH, s.health);
        this.setAttribute(EntityAttributes.GENERIC_MOVEMENT_SPEED, s.speed);
        this.setAttribute(EntityAttributes.GENERIC_ATTACK_DAMAGE, s.attackDamage);
        this.setAttribute(EntityAttributes.GENERIC_ARMOR, s.armor);
        this.setAttribute(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, s.knockbackResistance);
        this.setAttribute(EntityAttributes.GENERIC_FOLLOW_RANGE, s.followRange);

        if (resetHealth || this.getHealth() > this.getMaxHealth()) {
            this.setHealth(this.getMaxHealth());
        }

        this.dataTracker.set(BOX_W, (float) s.hitboxWidth);
        this.dataTracker.set(BOX_H, (float) s.hitboxHeight);

        this.setInvulnerable(s.invulnerable);
        this.setSilent(s.silent);
        this.setNoGravity(s.noGravity);
        this.setGlowing(s.glowing);

        if (!s.name.isBlank()) {
            this.setCustomName(Text.literal(s.name));
            this.setCustomNameVisible(s.nameVisible);
        } else {
            this.setCustomName(null);
            this.setCustomNameVisible(false);
        }

        this.setPersistent();
        this.rebuildGoals();

        if (!this.getWorld().isClient) {
            this.loadForm(s.form);
        }
    }

    private void setAttribute(EntityAttribute attribute, double value) {
        EntityAttributeInstance instance = this.getAttributeInstance(attribute);

        if (instance != null) {
            instance.setBaseValue(value);
        }
    }

    // ---------------- behaviour ----------------

    @Override
    protected void initGoals() {
        this.rebuildGoals();
    }

    private void rebuildGoals() {
        this.goalSelector.clear(goal -> true);
        this.targetSelector.clear(goal -> true);

        MobSettings.Mode mode = this.settings == null ? MobSettings.Mode.NORMAL : this.settings.mode;

        // "Stand still" = AI switched off completely (it still obeys gravity/knockback).
        this.setAiDisabled(mode == MobSettings.Mode.STILL);

        if (mode == MobSettings.Mode.STILL) {
            return;
        }

        this.goalSelector.add(1, new SwimGoal(this));

        if (mode == MobSettings.Mode.HOSTILE) {
            this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0, false));
            this.targetSelector.add(0, new RevengeGoal(this));
            this.targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
        }

        this.goalSelector.add(5, new WanderAroundFarGoal(this, 1.0));
        this.goalSelector.add(6, new LookAtEntityGoal(this, PlayerEntity.class, 8.0F));
        this.goalSelector.add(7, new LookAroundGoal(this));
    }

    @Override
    public boolean canImmediatelyDespawn(double distanceSquared) {
        return false;
    }

    @Override
    public boolean isFireImmune() {
        return (this.settings != null && this.settings.fireImmune) || super.isFireImmune();
    }

    @Override
    public void tick() {
        super.tick();

        if (this.form != null) {
            this.form.update(this.mcEntity);
        }
    }

    // ---------------- BBS form (morph) ----------------

    private void loadForm(String data) {
        Form loaded;

        try {
            loaded = (data == null || data.isEmpty())
                ? defaultForm()
                : FormUtils.fromData(DataToString.mapFromString(data));
        } catch (Exception e) {
            loaded = null;
        }

        if (loaded == null) {
            loaded = defaultForm();
        }

        this.setForm(loaded);

        if (this.getWorld() instanceof ServerWorld) {
            for (ServerPlayerEntity player : PlayerLookup.tracking(this)) {
                ServerNetwork.sendEntityForm(player, this);
            }
        }
    }

    @Override
    public int getEntityId() {
        return this.getId();
    }

    @Override
    public Form getForm() {
        return this.form;
    }

    @Override
    public void setForm(Form form) {
        Form last = this.form;
        this.form = form;

        if (!this.getWorld().isClient) {
            if (last != null) {
                last.onDemorph(this);
            }

            if (form != null) {
                form.onMorph(this);
            }
        }
    }

    public MCEntity getEntity() {
        return this.mcEntity;
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) {
        super.onStartedTrackingBy(player);

        if (this.form != null) {
            ServerNetwork.sendEntityForm(player, this);
        }
    }

    // ---------------- saving ----------------

    @Override
    public void writeCustomDataToNbt(NbtCompound nbt) {
        super.writeCustomDataToNbt(nbt);

        if (this.settings != null) {
            nbt.put("MobSettings", this.settings.toNbt());
        }
    }

    @Override
    public void readCustomDataFromNbt(NbtCompound nbt) {
        super.readCustomDataFromNbt(nbt);

        if (nbt.contains("MobSettings")) {
            this.applySettings(MobSettings.fromNbt(nbt.getCompound("MobSettings")), false);
        }
    }
}
