package bbsmobspawner.client;

import bbsmobspawner.MobEggItem;
import bbsmobspawner.MobSpawnerMod;
import mchorse.bbs_mod.ui.framework.UIScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

@Environment(EnvType.CLIENT)
public class MobSpawnerClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(MobSpawnerMod.MOB, CustomMobRenderer::new);

        // Spawn egg colours (green body, gold spots).
        ColorProviderRegistry.ITEM.register((stack, tint) -> tint == 0 ? 0x4C9A2A : 0xF2C94C, MobSpawnerMod.EGG);

        MobEggItem.openMenu = pos -> UIScreen.open(new UIMobSettingsMenu(pos));
    }
}
