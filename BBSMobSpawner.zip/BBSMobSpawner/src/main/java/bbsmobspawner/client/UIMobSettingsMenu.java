package bbsmobspawner.client;

import bbsmobspawner.CustomMobEntity;
import bbsmobspawner.MobSettings;
import bbsmobspawner.MobSpawnerMod;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import mchorse.bbs_mod.data.DataToString;
import mchorse.bbs_mod.forms.FormUtils;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.l10n.keys.IKey;
import mchorse.bbs_mod.ui.forms.UIFormPalette;
import mchorse.bbs_mod.ui.forms.UINestedEdit;
import mchorse.bbs_mod.ui.framework.UIBaseMenu;
import mchorse.bbs_mod.ui.framework.elements.UIElement;
import mchorse.bbs_mod.ui.framework.elements.UIScrollView;
import mchorse.bbs_mod.ui.framework.elements.buttons.UIButton;
import mchorse.bbs_mod.ui.framework.elements.buttons.UICirculate;
import mchorse.bbs_mod.ui.framework.elements.buttons.UIToggle;
import mchorse.bbs_mod.ui.framework.elements.input.UITrackpad;
import mchorse.bbs_mod.ui.framework.elements.input.text.UITextbox;
import mchorse.bbs_mod.ui.utils.UI;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.math.BlockPos;

/** The menu that opens when you use the Custom Mob Spawn Egg. Built on BBS's own UI framework. */
@Environment(EnvType.CLIENT)
public class UIMobSettingsMenu extends UIBaseMenu {
    private final BlockPos pos;
    private MobSettings s;
    private Form form;
    private UINestedEdit morph;
    private String presetName = "";

    public UIMobSettingsMenu(BlockPos pos) {
        this.pos = pos;
        this.s = PresetStore.loadLast();
        this.form = this.parseForm(this.s.form);

        this.build();
    }

    private Form parseForm(String data) {
        try {
            if (data != null && !data.isEmpty()) {
                Form parsed = FormUtils.fromData(DataToString.mapFromString(data));

                if (parsed != null) {
                    return parsed;
                }
            }
        } catch (Exception ignored) { }

        return CustomMobEntity.defaultForm();
    }

    private void syncForm() {
        this.s.form = DataToString.toString(FormUtils.toData(this.form));
    }

    private UITrackpad track(double value, double min, double max, double increment, Consumer<Double> callback) {
        UITrackpad trackpad = new UITrackpad(callback);

        trackpad.limit(min, max);
        trackpad.increment(increment);
        trackpad.setValue(value);

        return trackpad;
    }

    private UIToggle toggle(String label, boolean value, Consumer<Boolean> callback) {
        return new UIToggle(IKey.raw(label), value, t -> callback.accept(t.getValue()));
    }

    private void build() {
        this.main.removeAll();

        List<UIElement> e = new ArrayList<>();

        e.add(UI.label(IKey.raw("Custom Mob Spawner"), 16));

        // ---- identity ----
        UITextbox name = new UITextbox(64, t -> this.s.name = t);
        name.setText(this.s.name);
        e.add(UI.labelRow(IKey.raw("Name"), 160, name));
        e.add(this.toggle("Show name above head", this.s.nameVisible, v -> this.s.nameVisible = v));

        // ---- behaviour ----
        UICirculate mode = new UICirculate(c -> this.s.mode = MobSettings.Mode.values()[c.getValue()]);
        mode.addLabel(IKey.raw("Normal"));
        mode.addLabel(IKey.raw("Hostile"));
        mode.addLabel(IKey.raw("Stand still"));
        mode.setValue(this.s.mode.ordinal());
        e.add(UI.labelRow(IKey.raw("Behavior"), 160, mode));

        // ---- stats ----
        e.add(UI.label(IKey.raw("Stats"), 16));
        e.add(UI.labelRow(IKey.raw("Health"), this.track(this.s.health, 1, 1024, 1, v -> this.s.health = v)));
        e.add(UI.labelRow(IKey.raw("Speed (0.25 = normal)"), this.track(this.s.speed, 0, 5, 0.01, v -> this.s.speed = v)));
        e.add(UI.labelRow(IKey.raw("Attack damage"), this.track(this.s.attackDamage, 0, 2048, 0.5, v -> this.s.attackDamage = v)));
        e.add(UI.labelRow(IKey.raw("Armor"), this.track(this.s.armor, 0, 30, 1, v -> this.s.armor = v)));
        e.add(UI.labelRow(IKey.raw("Knockback resist."), this.track(this.s.knockbackResistance, 0, 1, 0.05, v -> this.s.knockbackResistance = v)));
        e.add(UI.labelRow(IKey.raw("Follow range"), this.track(this.s.followRange, 1, 128, 1, v -> this.s.followRange = v)));
        e.add(UI.labelRow(IKey.raw("Hitbox width"), this.track(this.s.hitboxWidth, 0.1, 16, 0.05, v -> this.s.hitboxWidth = v)));
        e.add(UI.labelRow(IKey.raw("Hitbox height"), this.track(this.s.hitboxHeight, 0.1, 16, 0.05, v -> this.s.hitboxHeight = v)));

        // ---- flags ----
        e.add(UI.label(IKey.raw("Flags"), 16));
        e.add(this.toggle("Invulnerable", this.s.invulnerable, v -> this.s.invulnerable = v));
        e.add(this.toggle("Fire immune", this.s.fireImmune, v -> this.s.fireImmune = v));
        e.add(this.toggle("No gravity (floats)", this.s.noGravity, v -> this.s.noGravity = v));
        e.add(this.toggle("Silent", this.s.silent, v -> this.s.silent = v));
        e.add(this.toggle("Glowing outline", this.s.glowing, v -> this.s.glowing = v));

        // ---- morph ----
        e.add(UI.label(IKey.raw("Morph (any BBS form, Steve avatar by default)"), 16));
        this.morph = new UINestedEdit(editing -> UIFormPalette.open(this.main, editing, this.form, picked -> {
            this.form = picked == null ? CustomMobEntity.defaultForm() : picked;
            this.morph.setForm(this.form);
        }));
        this.morph.setForm(this.form);
        e.add(UI.labelRow(IKey.raw("Morph"), 160, this.morph));

        // ---- presets ----
        e.add(UI.label(IKey.raw("Presets"), 16));

        UITextbox presetBox = new UITextbox(32, t -> this.presetName = t);
        presetBox.setText(this.presetName);
        presetBox.placeholder(IKey.raw("Preset name"));

        UIButton save = new UIButton(IKey.raw("Save"), b -> {
            String trimmed = this.presetName.trim();

            if (!trimmed.isEmpty()) {
                this.syncForm();
                PresetStore.save(trimmed, this.s);
                this.build();
            }
        });

        e.add(UI.row(4, 0, 20, presetBox, save));

        for (String preset : PresetStore.names()) {
            UIButton load = new UIButton(IKey.raw("Load: " + preset), b -> {
                MobSettings loaded = PresetStore.load(preset);

                if (loaded != null) {
                    this.s = loaded;
                    this.form = this.parseForm(loaded.form);
                    this.build();
                }
            });
            UIButton delete = new UIButton(IKey.raw("Delete"), b -> {
                PresetStore.delete(preset);
                this.build();
            });

            e.add(UI.row(4, 0, 20, load, delete));
        }

        // ---- actions ----
        UIButton spawn = new UIButton(IKey.raw("Spawn"), b -> this.spawn());
        UIButton cancel = new UIButton(IKey.raw("Cancel"), b -> this.closeThisMenu());

        e.add(UI.row(4, 0, 22, spawn, cancel));

        UIScrollView view = UI.scrollView(5, 10, e.toArray(new UIElement[0]));

        view.relative(this.main).x(0.5F, -170).y(10).w(340).h(1F, -20);
        this.main.add(view);
        this.main.resize();
    }

    private void spawn() {
        this.syncForm();
        PresetStore.saveLast(this.s);

        PacketByteBuf buf = PacketByteBufs.create();

        buf.writeBlockPos(this.pos);
        buf.writeNbt(this.s.toNbt());

        ClientPlayNetworking.send(MobSpawnerMod.SPAWN_PACKET, buf);

        this.closeThisMenu();
    }
}
