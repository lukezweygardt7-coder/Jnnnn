package bbsmobspawner.client;

import bbsmobspawner.MobSettings;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.StringNbtReader;

/** Presets live in config/bbs_mob_spawner_presets.json (name -> settings as SNBT). */
@Environment(EnvType.CLIENT)
public class PresetStore {
    private static final String LAST = "__last";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("bbs_mob_spawner_presets.json");
    }

    private static Map<String, String> read() {
        try {
            if (Files.exists(file())) {
                Map<String, String> map = GSON.fromJson(Files.readString(file()), new TypeToken<LinkedHashMap<String, String>>() { }.getType());

                if (map != null) {
                    return map;
                }
            }
        } catch (Exception ignored) { }

        return new LinkedHashMap<>();
    }

    private static void write(Map<String, String> map) {
        try {
            Files.writeString(file(), GSON.toJson(map));
        } catch (Exception ignored) { }
    }

    private static MobSettings parse(String snbt) {
        try {
            NbtCompound nbt = StringNbtReader.parse(snbt);

            return MobSettings.fromNbt(nbt);
        } catch (Exception e) {
            return null;
        }
    }

    public static List<String> names() {
        List<String> names = new ArrayList<>(read().keySet());

        names.remove(LAST);

        return names;
    }

    public static void save(String name, MobSettings settings) {
        Map<String, String> map = read();

        map.put(name, settings.toNbt().toString());
        write(map);
    }

    public static MobSettings load(String name) {
        String snbt = read().get(name);

        return snbt == null ? null : parse(snbt);
    }

    public static void delete(String name) {
        Map<String, String> map = read();

        map.remove(name);
        write(map);
    }

    public static MobSettings loadLast() {
        MobSettings last = load(LAST);

        return last == null ? new MobSettings() : last;
    }

    public static void saveLast(MobSettings settings) {
        save(LAST, settings);
    }
}
