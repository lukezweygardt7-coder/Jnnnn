package bbsmobspawner.client;

import bbsmobspawner.CustomMobEntity;
import com.mojang.blaze3d.systems.RenderSystem;
import mchorse.bbs_mod.client.renderer.DeathPose;
import mchorse.bbs_mod.forms.FormUtilsClient;
import mchorse.bbs_mod.forms.forms.Form;
import mchorse.bbs_mod.forms.renderers.FormRenderType;
import mchorse.bbs_mod.forms.renderers.FormRenderingContext;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

/** Draws the mob as its BBS form, the same way BBS draws its own actors. */
@Environment(EnvType.CLIENT)
public class CustomMobRenderer extends EntityRenderer<CustomMobEntity> {
    public CustomMobRenderer(EntityRendererFactory.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.0F;
    }

    @Override
    public Identifier getTexture(CustomMobEntity entity) {
        return new Identifier("minecraft:textures/entity/player/wide/steve.png");
    }

    @Override
    public void render(CustomMobEntity entity, float yaw, float tickDelta, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light) {
        Form form = entity.getForm();

        if (form == null) {
            return;
        }

        matrices.push();

        float bodyYaw = MathHelper.lerpAngleDegrees(tickDelta, entity.prevBodyYaw, entity.bodyYaw);
        int overlay = LivingEntityRenderer.getOverlay(entity, 0.0F);

        if (!entity.isInPose(EntityPose.SLEEPING)) {
            matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-bodyYaw));
        }

        DeathPose.apply(matrices, entity.deathTime, tickDelta);

        RenderSystem.enableBlend();
        RenderSystem.enableDepthTest();

        FormUtilsClient.render(
            form,
            new FormRenderingContext()
                .set(FormRenderType.ENTITY, entity.getEntity(), matrices, light, overlay, tickDelta)
                .camera(MinecraftClient.getInstance().gameRenderer.getCamera())
        );

        RenderSystem.disableDepthTest();
        RenderSystem.disableBlend();

        matrices.pop();

        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }
}
