package bbsmobspawner;

import net.minecraft.nbt.NbtCompound;

/** Every option the spawn-egg menu can set. Serialised to NBT for packets, saving and presets. */
public class MobSettings {
    public enum Mode { NORMAL, HOSTILE, STILL }

    public String name = "";
    public boolean nameVisible = true;
    public Mode mode = Mode.NORMAL;

    public double health = 20;
    public double speed = 0.25;
    public double attackDamage = 2;
    public double armor = 0;
    public double knockbackResistance = 0;
    public double followRange = 32;
    public double hitboxWidth = 0.6;
    public double hitboxHeight = 1.8;

    public boolean invulnerable = false;
    public boolean silent = false;
    public boolean noGravity = false;
    public boolean fireImmune = false;
    public boolean glowing = false;

    /** BBS form data (JSON) of the chosen morph. Empty = default Steve avatar. */
    public String form = "";

    public NbtCompound toNbt() {
        NbtCompound n = new NbtCompound();
        n.putString("name", name);
        n.putBoolean("nameVisible", nameVisible);
        n.putString("mode", mode.name());
        n.putDouble("health", health);
        n.putDouble("speed", speed);
        n.putDouble("attackDamage", attackDamage);
        n.putDouble("armor", armor);
        n.putDouble("knockbackResistance", knockbackResistance);
        n.putDouble("followRange", followRange);
        n.putDouble("hitboxWidth", hitboxWidth);
        n.putDouble("hitboxHeight", hitboxHeight);
        n.putBoolean("invulnerable", invulnerable);
        n.putBoolean("silent", silent);
        n.putBoolean("noGravity", noGravity);
        n.putBoolean("fireImmune", fireImmune);
        n.putBoolean("glowing", glowing);
        n.putString("form", form);
        return n;
    }

    public static MobSettings fromNbt(NbtCompound n) {
        MobSettings s = new MobSettings();
        if (n == null) return s;
        if (n.contains("name")) s.name = n.getString("name");
        if (s.name.length() > 64) s.name = s.name.substring(0, 64);
        if (n.contains("nameVisible")) s.nameVisible = n.getBoolean("nameVisible");
        try { s.mode = Mode.valueOf(n.getString("mode")); } catch (Exception ignored) { }
        if (n.contains("health")) s.health = n.getDouble("health");
        if (n.contains("speed")) s.speed = n.getDouble("speed");
        if (n.contains("attackDamage")) s.attackDamage = n.getDouble("attackDamage");
        if (n.contains("armor")) s.armor = n.getDouble("armor");
        if (n.contains("knockbackResistance")) s.knockbackResistance = n.getDouble("knockbackResistance");
        if (n.contains("followRange")) s.followRange = n.getDouble("followRange");
        if (n.contains("hitboxWidth")) s.hitboxWidth = n.getDouble("hitboxWidth");
        if (n.contains("hitboxHeight")) s.hitboxHeight = n.getDouble("hitboxHeight");
        s.invulnerable = n.getBoolean("invulnerable");
        s.silent = n.getBoolean("silent");
        s.noGravity = n.getBoolean("noGravity");
        s.fireImmune = n.getBoolean("fireImmune");
        s.glowing = n.getBoolean("glowing");
        if (n.contains("form")) s.form = n.getString("form");

        // Keep everything inside what Minecraft's attributes allow.
        s.health = clamp(s.health, 1, 1024);
        s.speed = clamp(s.speed, 0, 5);
        s.attackDamage = clamp(s.attackDamage, 0, 2048);
        s.armor = clamp(s.armor, 0, 30);
        s.knockbackResistance = clamp(s.knockbackResistance, 0, 1);
        s.followRange = clamp(s.followRange, 1, 128);
        s.hitboxWidth = clamp(s.hitboxWidth, 0.1, 16);
        s.hitboxHeight = clamp(s.hitboxHeight, 0.1, 16);
        return s;
    }

    public MobSettings copy() {
        return fromNbt(toNbt());
    }

    private static double clamp(double v, double min, double max) {
        if (Double.isNaN(v)) return min;
        return Math.max(min, Math.min(max, v));
    }
}
