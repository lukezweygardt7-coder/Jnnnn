package bbsmobspawner;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class MobSpawnerMod implements ModInitializer {
    public static final String ID = "bbsmobspawner";
    public static final Identifier SPAWN_PACKET = new Identifier(ID, "spawn");

    public static final EntityType<CustomMobEntity> MOB = Registry.register(
        Registries.ENTITY_TYPE,
        new Identifier(ID, "custom_mob"),
        FabricEntityTypeBuilder.<CustomMobEntity>create(SpawnGroup.MISC, CustomMobEntity::new)
            .dimensions(EntityDimensions.fixed(0.6F, 1.8F))
            .trackRangeBlocks(80)
            .trackedUpdateRate(3)
            .build()
    );

    public static final Item EGG = Registry.register(
        Registries.ITEM,
        new Identifier(ID, "custom_mob_spawn_egg"),
        new MobEggItem(new Item.Settings().maxCount(16))
    );

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(MOB, CustomMobEntity.createAttributes());

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(entries -> entries.add(EGG));

        ServerPlayNetworking.registerGlobalReceiver(SPAWN_PACKET, (server, player, handler, buf, sender) -> {
            BlockPos pos = buf.readBlockPos();
            NbtCompound nbt = buf.readNbt();

            server.execute(() -> spawn(player, pos, nbt));
        });
    }

    private static void spawn(ServerPlayerEntity player, BlockPos pos, NbtCompound nbt) {
        if (!(player.isCreative() || player.hasPermissionLevel(2))) {
            player.sendMessage(Text.literal("You need creative mode or operator permissions to spawn custom mobs."), true);
            return;
        }

        if (player.squaredDistanceTo(Vec3d.ofCenter(pos)) > 64 * 64) {
            return;
        }

        ItemStack held = null;

        for (Hand hand : Hand.values()) {
            if (player.getStackInHand(hand).isOf(EGG)) {
                held = player.getStackInHand(hand);
                break;
            }
        }

        if (held == null && !player.isCreative()) {
            return;
        }

        ServerWorld world = player.getServerWorld();
        CustomMobEntity mob = MOB.create(world);

        if (mob == null) {
            return;
        }

        mob.refreshPositionAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, player.getYaw() + 180F, 0F);
        mob.applySettings(MobSettings.fromNbt(nbt), true);
        world.spawnEntity(mob);

        if (held != null && !player.isCreative()) {
            held.decrement(1);
        }
    }
}
