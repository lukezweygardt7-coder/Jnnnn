package bbsmobspawner;

import java.util.function.Consumer;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/** Right-click (block or air) opens the settings menu on the client. The server spawns when the menu sends its packet. */
public class MobEggItem extends Item {
    /** Set by the client initializer so this class never touches client-only code. */
    public static Consumer<BlockPos> openMenu = pos -> { };

    public MobEggItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();

        if (world.isClient) {
            openMenu.accept(context.getBlockPos().offset(context.getSide()));
        }

        return ActionResult.success(world.isClient);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (world.isClient) {
            openMenu.accept(user.getBlockPos());
        }

        return TypedActionResult.success(stack, world.isClient);
    }
}
