BBS Mob Spawner  (add-on for BBS, Minecraft 1.20.1, Fabric)

What it adds
- "Custom Mob Spawn Egg" (Spawn Eggs creative tab).
- Right-click with it -> a menu opens. Set: name, behavior (Normal / Hostile / Stand still),
  health, speed, attack damage, armor, knockback resistance, follow range, hitbox size,
  invulnerable, fire immune, no gravity, silent, glowing.
- Morph: pick ANY BBS form (Pick) or edit it (Edit). Default is the Steve avatar
  (BBS's built-in player/steve model) - use Edit to put your own skin texture on it.
- Presets: type a name + Save; Load / Delete below. Saved to config/bbs_mob_spawner_presets.json.
- The mob is a normal mob, NOT a BBS film actor.
- Survival: needs the egg in hand (consumed). Needs creative or op level 2 to spawn.

Credits
- BBS by McHorse and Wemppy; BBS LX 1.0 edit by Luxuryonez. This add-on does not copy or
  modify their code; it only uses BBS's public add-on API and classes. BBS must be installed.
