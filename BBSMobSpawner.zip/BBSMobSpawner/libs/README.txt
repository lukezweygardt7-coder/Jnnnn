The GitHub workflow copies your BBS jar here as libs/bbs.jar automatically.
If building locally, put your BBS jar here and name it bbs.jar.
